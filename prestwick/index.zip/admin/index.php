<?php
    require("components/admin-header-links-inc.php");
?>
</head>
<body>
    <main>
        <?php require("components/admin-left-inc.php"); ?>
        <?php require("components/admin-header-inc.php"); ?>
        <section>
            <div class="container">
                <div class="row">                    
                    <div class="col-12">
                        <a href="javascript:void(0)" class="buttonStyle ms-auto">Export</a>
                    </div>                    
                    <div class="col-12">
                        <div class="displayRecord">
                            <table class="table border-0">
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox" id="filterCheckBox" />
                                            <!-- <div class="checkboxBg"></div> -->
                                        </th>
                                        <th>Name</th>
                                        <th>Address</th>
                                        <th>DOB</th>
                                        <th>type of licence</th>
                                        <th>MDP expiry</th>
                                        <th>SEP Expiry</th>
                                        <th>MEP Expiry</th>
                                        <th>IR Expiry</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                      $selectMembers = commonSelect_table($conn, "member_registration", "id^member_name^address^DOB^CAA_ref_no^licence_number^SEP_expiry^MEP_expiry^medical_class1_expiry^medical_class2_expiry^medical_LAPL_expiry^status", "");

                                        $numRows = mysqli_num_rows($selectMembers);
                                        if($numRows > 0){
                                            while($fetch_all = mysqli_fetch_array($selectMembers)){
                                                
                                                $member_name = $fetch_all['member_name'];
                                                $address = $fetch_all['address'];
                                                $DOB = $fetch_all['DOB'];
                                                $CAA_ref_no = $fetch_all['CAA_ref_no'];
                                                $SEP_expiry = $fetch_all['SEP_expiry'];
                                                $MEP_expiry = $fetch_all['MEP_expiry'];
                                                $medical_class1_expiry = $fetch_all['medical_class1_expiry'];
                                                $medical_class2_expiry = $fetch_all['medical_class2_expiry'];
                                                $medical_LAPL_expiry = $fetch_all['medical_LAPL_expiry'];
                                                $licence_number = $fetch_all['licence_number'];

                                                $tr = "<tr>";
                                                $tr .= "<td><input type='checkbox' id='singleDataCheckBox' /></td>";
                                                $tr .= "<td>$member_name</td>";
                                                $tr .= "<td>$address</td>";
                                                $tr .= "<td>$DOB</td>";
                                                $tr .= "<td>$CAA_ref_no</td>";
                                                $tr .= "<td>$SEP_expiry</td>";
                                                $tr .= "<td>$MEP_expiry</td>";
                                                $tr .= "<td>$medical_class1_expiry</td>";
                                                $tr .= "<td>$medical_class2_expiry</td>";
                                                // $tr .= "<td>$medical_LAPL_expiry</td>";
                                                // $tr .= "<td>$medical_class2_expiry</td>";
                                                $tr .= "</tr>";
                                                echo $tr;
                                            }
                                        }
                                        else{
                                            echo"<tr><p>No Record Found</p></tr>";
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php
    require("components/admin-footer-inc.php");
?>  
</body>
</html>