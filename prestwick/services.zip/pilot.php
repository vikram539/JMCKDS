<?php
    require("assets/header.php");
?>
</head>
    <body>
        <section class="pilotHeader">
            <?php require("assets/navbar.php"); ?>
            <?php require("assets/pilotHeaderCaption.php"); ?>
        </section> 
        
        <?php require("assets/pilotForm.php"); ?>  
    
        <?php require("assets/footer.php"); ?>
    </body>
</html>