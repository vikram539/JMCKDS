<section class="leftBarWrap">
    <aside>
        <div class="row">
            <div class="col-12">
                <div class="dashboardBar">
                    <ul>
                        <li><a href=""><img src="<?=$adminImgURL?>search.png" class="img-fluid" /></a></li>
                        <li><a href=""><img src="<?=$adminImgURL?>article.png" class="img-fluid" /></a></li>
                        <li><a href=""><img src="<?=$adminImgURL?>notifications.png" class="img-fluid" /></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </aside>
</section>