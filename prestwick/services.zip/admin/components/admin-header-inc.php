<header class='topheader'>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-6 col-lg-8">
                <div class="welcomeText">
                    <h4>Welcome to the Dasboard, <strong>Roni Chaterjee</strong></h4>
                </div>
            </div>
            <div class="col-6 col-lg-4">
                <div class="logo">
                    <img src="<?=$adminImgURL?>logo.png" class="img-fluid" />
                </div>
            </div>
        </div>
    </div>
</header>