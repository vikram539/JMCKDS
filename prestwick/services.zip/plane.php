<?php
    require("assets/header.php");
?>
</head>
    <body>
        <section class="planeHeader">
            <?php require("assets/navbar.php"); ?>
            <?php require("assets/planeHeaderCaption.php"); ?>
        </section> 
        
        <?php require("assets/planeForm.php"); ?>  
    
        <?php require("assets/footer.php"); ?>
    </body>
</html>