<?php
@$admin_url=$website_domain."webdesignbank-admin/";

@$admin_images=$admin_url."images/";
?>