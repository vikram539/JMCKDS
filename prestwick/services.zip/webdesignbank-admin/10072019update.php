<?php
session_start();
include('php-function/function.php');
$fun_obj->UpdateText();

?>