<?php
    require("assets/header.php");
?>
</head>
    <body>
        <section class="membershipHeader">
            <?php require("assets/navbar.php"); ?>
            <?php require("assets/membership-header-caption.php"); ?>
        </section> 
        
        <?php require("assets/membership-form.php"); ?>  
    
        <?php require("assets/footer.php"); ?>
    </body>
</html>