<?php
foreach($serviceArray as $servicesNAme){

    echo"<li class='col-xs-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6'>
        <div class='border-box'>
            <h4>".$servicesNAme."</h4>
        </div>                               
    </li>";
}
?>