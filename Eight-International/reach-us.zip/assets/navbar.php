<nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
        <a class="navbar-brand" href="<?= $root ?>">
            <img src="<?= $images ?>logo.png" alt="<?= $name ?>" class="img-fluid" />
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?= $root ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= $root ?>about-us.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= $root ?>our-specialities.php">Our Specialities</a>
                <!-- </li>
                <li class="nav-item">
                    <a class="nav-link" href="">Contact</a>
                </li> -->
                <li class="nav-item">
                    <a class="nav-link" href="<?= $root ?>reach-us.php">Call Me Back!</a>
                </li>
            </ul>
        </div>
  </div>
</nav>