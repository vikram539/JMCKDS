
<div class="modal fade servicesModal" id="modal_1" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">           
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <img src="<?=$images?>services/1.png" class="img-fluid d-block mx-auto" />
                <h4>Financial Planning</h4>
                <p  class='mb-4'>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Hac bibendum vitae pellentesque tellus, diam dignissim vestibulum, erat lectus. Enim orci velit ut fames egestas nisl in felis quis. Nulla morbi quis pellentesque posuere in arcu. Sed sollicitudin ultricies risus, eget at non nisi Diam varius mauris tristique ullamcorper. Diam tortor scelerisque blandit adipiscing. Malesuada elementum platea enim gravida sem est. Euismod tincidunt nullam nulla id est. Aliquam quam nulla sit dui. Tortor, posuere dolor sed eget. Cras vehicula.</p>
            </div>
        </div>
    </div>
</div> 