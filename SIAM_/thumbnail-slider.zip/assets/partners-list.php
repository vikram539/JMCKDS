<section class='w-100'>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="partnersList">
                    <ul class='partners'>
                        <li><a href="<?=$root?>financial-institutions.php">Financial Institutions</a></li>
                        <li><a href="<?=$root?>mining-companies.php">Mining Companies</a></li>
                        <li><a href="<?=$root?>metal-purifiers.php">Metal Purifiers</a></li>
                        <li><a href="<?=$root?>commodity-firms.php">Commodity Firms</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>