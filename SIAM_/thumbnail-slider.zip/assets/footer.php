<footer>
    <div class="container">
        <div class="row">
            <div class="col-6">
                <div class="footerPolicy">
                    <p>&copy; Swiss Asset Management All rights reserved</p>
                </div>
            </div>
            <div class="col-6">
                <div class="footerPolicy text-end">
                    <p><a href='<?=$root?>' >Privacy Policy</a> / <a href='<?=$root?>' >Terms of use</a></p>
                </div>
            </div>
        </div>
    </div>
</footer>
<script src="https://kit.fontawesome.com/3fd486c100.js" crossorigin="anonymous"></script>
<script src="<?=$root?>js/app.js" type="text/javascript"></script>
